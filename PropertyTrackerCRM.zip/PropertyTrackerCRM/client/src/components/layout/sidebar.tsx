import { Users, Building, Calendar, BarChart3, Briefcase } from "lucide-react";
import { cn } from "@/lib/utils";

type TabType = "clients" | "properties" | "meetings" | "analytics" | "portfolio";

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const navigation = [
  { name: "Clients", tab: "clients" as TabType, icon: Users },
  { name: "Properties", tab: "properties" as TabType, icon: Building },
  { name: "Meeting Scheduler", tab: "meetings" as TabType, icon: Calendar },
  { name: "Analytics", tab: "analytics" as TabType, icon: BarChart3 },
  { name: "Portfolio", tab: "portfolio" as TabType, icon: Briefcase },
];

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <nav className="w-64 bg-surface shadow-sm h-screen sticky top-0">
      <div className="p-6">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.tab;
            
            return (
              <li key={item.tab}>
                <button
                  onClick={() => onTabChange(item.tab)}
                  className={cn(
                    "w-full text-left px-4 py-3 rounded-lg font-medium flex items-center space-x-3 transition-colors",
                    isActive
                      ? "bg-primary text-white"
                      : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
