import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { ClientsTab } from "@/components/clients/clients-tab";
import { PropertiesTab } from "@/components/properties/properties-tab";
import { MeetingsTab } from "@/components/meetings/meetings-tab";
import { AnalyticsTab } from "@/components/analytics/analytics-tab";
import { PortfolioTab } from "@/components/portfolio/portfolio-tab";

type TabType = "clients" | "properties" | "meetings" | "analytics" | "portfolio";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("clients");

  const renderActiveTab = () => {
    switch (activeTab) {
      case "clients":
        return <ClientsTab />;
      case "properties":
        return <PropertiesTab />;
      case "meetings":
        return <MeetingsTab />;
      case "analytics":
        return <AnalyticsTab />;
      case "portfolio":
        return <PortfolioTab />;
      default:
        return <ClientsTab />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 overflow-hidden">
          {renderActiveTab()}
        </main>
      </div>
    </div>
  );
}
